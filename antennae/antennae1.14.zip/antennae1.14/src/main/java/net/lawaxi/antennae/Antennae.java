package net.lawaxi.antennae;

import net.fabricmc.api.ModInitializer;

public class Antennae implements ModInitializer {
	@Override
	public void onInitialize() {

		System.out.println("啦哇嘻触角模组 1.14专用");
		System.out.println("您可以正版登录前往mc.lawaxi.net 使用/cape指令设置您的披风");


	}
}
